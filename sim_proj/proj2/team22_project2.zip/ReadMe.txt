Group Members:
Anatolie Chernyakhovsky - asc109
Armando Gallegos	- a_g345

to run the program, you type ./team22_project2.py into the console on Linux