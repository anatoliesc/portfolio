Group Members:
Anatolie Chernyakhovsky - asc109
Armando Gallegos	         - a_g345

to run the program, you type ./team22_project1.py into the console on Linux

The program uses the absolute file address (not relative) to create its output folder, so you'll have to change your working directory to get the output file to generate.

Known issues:
Branch instruction does not correctly get converted into 2's complement.