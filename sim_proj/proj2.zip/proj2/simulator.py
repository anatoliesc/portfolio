import masking_constants as MASKs
import state as State
from helpers import SetUp

class Simulator:

    def __init__(self, opcode, dataval, address, arg1, arg2, arg3, numInstructs, opcodeStr, arg1Str, arg2Str, arg3Str):
        # self.instructions = instrs
        self.opcode = opcode
        self.datatval = dataval
        self.address = address
        self.numInstructions = numInstructs
        self.arg1 = arg1
        self.arg2 = arg2
        self.arg3 = arg3
        self.opcodeStr = opcodeStr
        self.arg1Str = arg1Str
        self.arg2Str = arg2Str
        self.arg3Str = arg3Str
        self.specialMask = MASKs.specialMask

    def run(self):
        foundBreak = False
        armState = State(self.opcode, self.datatval, self.address, self.arg1, self.arg2, self.arg3,
                         self.numInstructions, self.opcodeStr, self.arg1Str, self.arg2Str, self.arg3Str)

        while not foundBreak:
            jumpAddr = armState.PC
            # get the next instruction
            i = armState.getIndexOfMemAddress(armState.PC)

            # TODO test and delete the need for instructions
            # if self.instrctions[i] == '00000000000000000000000000000000' : # NOP this might still be wrong need to test more

            if self.opcode[i] == 0:  # NOP
                armState.printState()
                armState.incrementPC()
                armState.cycle += 1
                continue  # go right back to top

            elif 160 <= self.opcode[i] <= 191:  # B
                self.jumpAddr = jumpAddr + ((self.arg1[i] * 4) - 4)
                armState.printState()
                armState.incrementPC()
                armState.cycle += 1
                continue  # go right back to top

            elif self.opcode[i] == 1112:  # ADD
                self.arg3 = self.arg1 + self.arg2
                armState.printState()
                armState.incrementPC()
                armState.cycle += 1

            elif self.opcode[i] == 1624:  # SUB
                self.arg3 = self.arg1 - self.arg2
                armState.printState()
                armState.incrementPC()
                armState.cycle += 1

            elif self.opcode[i] == 1690:  # LSR
                self.arg3 = self.arg1 // (2 ** self.arg2)  # arg3 = arg1//2^arg2
                armState.printState()
                armState.incrementPC()
                armState.cycle += 1

            elif self.opcode[i] == 1691:  # LSL
                self.arg3 = self.arg1 * (2 ** self.arg2)  # arg3 = arg1*2^arg2
                armState.printState()
                armState.incrementPC()
                armState.cycle += 1

            elif self.opcode[i] == 1104:  # AND
                self.arg3 = self.arg1 & self.arg2
                armState.printState()
                armState.incrementPC()
                armState.cycle += 1

            elif self.opcode[i] == 1360:  # ORR
                self.arg3 = self.arg1 | self.arg2
                armState.printState()
                armState.incrementPC()
                armState.cycle += 1

            elif self.opcode[i] == 1872:  # EOR
                self.arg3 = self.arg1 ^ self.arg2
                armState.printState()
                armState.incrementPC()
                armState.cycle += 1

            elif self.opcode[i] == 1160 or self.opcode[i] == 1161:  # ADDI
                self.arg3 = self.arg1 + self.arg2
                armState.printState()
                armState.incrementPC()
                armState.cycle += 1

            elif self.opcode[i] == 1672 or self.opcode[i] == 1673:  # SUBI
                self.arg3 = self.arg1 - self.arg2
                armState.printState()
                armState.incrementPC()
                armState.cycle += 1

            elif self.opcode[i] == 1984:  # STUR
                self.address = self.arg1 + self.arg2
                self.dataval[self.address] = self.arg3
                armState.printState()
                armState.incrementPC()
                armState.cycle += 1

            elif self.opcode[i] == 1986:  # LDUR
                self.address = self.arg1 + self.arg2
                self.arg3 = self.dataval[self.address]
                armState.printState()
                armState.incrementPC()
                armState.cycle += 1

            elif self.opcode[i] >= 1440 or self.opcode[i] <= 1447:  # CBZ
                if self.arg1 == 0:
                    jumpAddr = self.arg1 + self.arg2
                armState.printState()
                armState.incrementPC()
                armState.cycle += 1

            elif self.opcode[i] >= 1448 or self.opcode[i] <= 1455:  # CBNZ
                if self.arg1 != 0:
                    jumpAddr = self.arg1 + self.arg2

            elif self.opcode[i] == 2038:  # Break
                foundBreak = True

            elif 1684 <= self.opcode[i] <= 1687:  # MOVZ
                self.arg3 = self.arg2 << self.arg1
                armState.printState()
                armState.incrementPC() #to do LSR do arg1 % 0x100000000 >> arg2
                armState.cycle += 1

            elif 1940 <= self.opcode[i] <= 1943:  # MOVK
                self.arg3 = self.arg3 << self.arg1 #CHANGE TO: arg3 = arg3 | (arg2 << arg1)
                armState.printState()
                armState.incrementPC()
                armState.cycle += 1

            else:
                print("IN SIM -- UNKNOWN INSTRUCTION ----------- !!!!")

            armState.printState()
            armState.PC = jumpAddr
            armState.incrementPC()
            armState.cycle += 1

        class State:
            dataval = []
            PC = 96
            cycle = 1
            R = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

            def __init__(self, opcode, dataval, addrs, arg1, arg2, arg3, numInstructs, opcodeStr, arg1Str, arg2Str,
                         arg3Str):
                # self.instructions = instrs
                self.datatval = None
                self.opcode = opcode
                self.dataval = dataval
                self.address = addrs
                self.numInstructions = numInstructs
                self.arg1 = arg1
                self.arg2 = arg2
                self.arg3 = arg3
                self.opcodeStr = opcodeStr
                self.arg1Str = arg1Str
                self.arg2Str = arg2Str
                self.arg3Str = arg3Str

            def getIndexOfMemAddress(self, currAddr):
                index = 0
                for i in self.address:
                    if i == currAddr:
                        return index
                    index += 1

            def incrementPC(self):
                self.pc = self.pc + 4

            def printState(self):

                outputFileName = SetUp.get_output_filename()

                with open(outputFileName + "_sim.txt", 'a') as outFile:

                    i = self.getIndexOfMemAddress(self, PC)
                    outFile.write("======================\n")
                    outFile.write(
                        "cycle: " + str(self.cycle) + "\t" + str(self.PC) + "\t" + self.opcodeStr[i] +
                        self.arg2Str[i] + self.arg3[i] + "\n")
                    outFile.write("\n")
                    outFile.write("registers: \n")

                    outStr = "r00:"
                    for i in range(0, 8):
                        outStr = outStr + "\t" + str(self.R[i])
                        outFile.write(outStr + "\n")

                    outStr = "r08:"
                    for i in range(0, 8):
                        outStr = outStr + "\t" + str(self.R[i])
                        outFile.write(outStr + "\n")

                    outStr = "r16:"
                    for i in range(0, 8):
                        outStr = outStr + "\t" + str(self.R[i])
                        outFile.write(outStr + "\n")

                    outStr = "r24:"
                    for i in range(0, 8):
                        outStr = outStr + "\t" + str(self.R[i])
                        outFile.write(outStr + "\n")

                    outFile.write("\n")

                    outFile.write("data:" + "\n")
                    for i in range(len(self.dataval)):

                        if (i % 8 == 0 and i != 0 or i == len(self.datatval)):
                            outFile.write(outStr + "\n")

                        if (i % 8 == 0):
                            outStr = str(self.address[i + self.numInstructions]) + ":" + str(self.datatval[i])

                        if (i % 8 != 0):
                            outStr = outStr + "\t" + str(self.datatval[i])

                    outFile.write(outStr + "\n")
                    outFile.close()

